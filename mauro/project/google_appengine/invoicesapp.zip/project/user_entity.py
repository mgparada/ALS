#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from google.appengine.ext import ndb

class User(ndb.Model):
    name = ndb.StringProperty( required = True )
    email = ndb.StringProperty( required = True )
    password = ndb.StringProperty( required = True )