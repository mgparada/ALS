#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from basehandler import BaseHandler
from bill_entity import Bill
from invoice_line import InvoiceLine

from google.appengine.ext import ndb

import json
import ast
import time
import jinja2
import os

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader( os.path.dirname( __file__ ) ),
    extensions=[ "jinja2.ext.autoescape" ],
    autoescape=True )

class BillHandler(BaseHandler):
    def __init__ (self, request=None, response=None):
        self.initialize(request, response)
        self.data = self.request.get( "form_data" )
        self.invoices_line = self.request.get( "invoice_line" )
    
    def getBill(self):
        bill_id = self.request.get("bill_id")
        bill = ndb.Key(Bill, int(bill_id)).get()
        
        invoices = InvoiceLine.query( InvoiceLine.bill_id == bill.key.id() ).fetch()
        
        count = 0
        for i in invoices: 
            invoices[count].concept = i.concept.replace("+", " ")
            count += 1 
#             invoices.concept = i.concept.replace("+", " ")
        
        template_values = {
                'bill': bill,
                'invoices': invoices
           }
        
        template = JINJA_ENVIRONMENT.get_template( "bill_details.html" )
        self.response.write( template.render(template_values) )
    
    def addBill(self):
        data = self.data.split("&")
        invoices = self.invoices_line.replace("\"", "").split("&")
        dict_data = {}
        dict_invoices = {}
        dict_d = {}
        
        for d in data[:-1]: 
            s = d.split("=")
            s[0] = s[0].encode("utf-8")
            s[1] = s[1].encode("utf-8")
            dict_data[s[0]] = s[1]
            
        count = 0

        for i in invoices[1:]:
            s = i.split("=")
            s[0] = s[0].encode("utf-8")
            s[1] = s[1].encode("utf-8")
 
            dict_d[s[0]] = s[1]
            
            if count > 0 and count%3 == 0:
                dict_invoices[len(dict_invoices)] = dict_d
                dict_d = {}
                count = -1
                
            count += 1
                 
        json_d = json.dumps(dict_data)
        dict_data = ast.literal_eval(json_d) 

        json_d = json.dumps(dict_invoices)
        dict_invoices = ast.literal_eval(json_d)
            
        bill = Bill (
               user_email = self.request.cookies.get("email"), 
               date = dict_data['date'], 
               pay_method = "1", 
               remitente_name = dict_data["remitente_name"], 
               remitente_cif = dict_data["remitente_cif"], 
               remitente_direccion = dict_data["remitente_direccion"],
               remitente_pais = dict_data["remitente_pais"], 
               remitente_email = dict_data["remitente_email"], 
               remitente_telefono = dict_data["remitente_telefono"], 
               destinatario_name = dict_data["destinatario_name"], 
               destinatario_cif = dict_data["destinatario_cif"], 
               destinatario_direccion = dict_data["destinatario_direccion"],
               destinatario_pais = dict_data["destinatario_pais"], 
               destinatario_email = dict_data["destinatario_email"].replace("%", "@"), 
               destinatario_telefono = dict_data["destinatario_telefono"]
           )
        bill.put()
         
        try:
            for i in dict_invoices:
                d = dict_invoices[i]
                invoice = InvoiceLine (
                            bill_id = bill.key.id(),
                            concept = d["lp_descripcion"],
                            amount = float(d["lp_unidades"]),
                            unit_price = float(d["lp_precio"]),
                            iva = float(d["lp_iva"])
                       )
                invoice.put()
                
            time.sleep(0.2)
        except:
            time.sleep(0.2)
        
        