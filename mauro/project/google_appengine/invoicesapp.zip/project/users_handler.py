#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import hashlib
import time

from basehandler import BaseHandler
from user_entity import User

from google.appengine.ext import ndb

class UserHandler(BaseHandler):
    def __init__ (self, request=None, response=None):
        self.initialize(request, response)
        self.name = self.request.get( "name" )
        self.email = self.request.get( "email" )
        self.password = self.request.get( "password" )
        
    def checkEmail(self):
        if User.query( User.email == self.email ).fetch() == []: 
            to_response = True 
        else:
            to_response = False
            
        self.response.write( to_response )
        
    def doLogin(self):
        user = User.query( User.email == self.email ).fetch()
        h = hashlib.md5()
        h.update(self.password)        
        
        if user == []:
            self.response.write( False )
            return False
        
        if user[0].email == self.email and user[0].password == h.hexdigest():
            self.response.set_cookie('login', "1")
            self.response.set_cookie("email", self.email)
            self.response.write( True )
        else:
            self.response.write( False )
            
    def doLogout(self):
        self.response.delete_cookie("login")
        self.response.delete_cookie("email")
        self.redirect("/")
        
    def post(self):
        h = hashlib.md5()
        h.update(self.password)
        
        user = User(name = self.name, email = self.email, password = h.hexdigest())
        user.put()
        
        time.sleep(0.2)
        self.response.set_cookie("login", "1")
        self.response.set_cookie("email", self.email)
        self.redirect("/dash")
        
    def changePass(self):
        try:
            h = hashlib.md5()
            h.update(self.request.get("password"))
            
            user = User.query( User.email == self.request.get("email") ).fetch()
            user[0].password = h.hexdigest()
            ndb.put_multi(user)
            
            self.response.write( True )
        except:
            self.response.write( False )
            
    def changeName (self):
        try:            
            user = User.query( User.email == self.request.get("email") ).fetch()
            user[0].name = self.request.get("name")
            ndb.put_multi(user)
            
            self.response.write( True )
        except:
            self.response.write( False )
