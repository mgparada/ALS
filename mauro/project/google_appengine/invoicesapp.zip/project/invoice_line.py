#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from google.appengine.ext import ndb

class InvoiceLine(ndb.Model):
    bill_id = ndb.IntegerProperty( required = True )
    concept = ndb.GenericProperty( required = True )
    amount = ndb.FloatProperty( required = True )
    unit_price = ndb.FloatProperty( required = True )
    iva = ndb.FloatProperty( required = True )