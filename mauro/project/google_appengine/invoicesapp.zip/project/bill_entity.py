#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from google.appengine.ext import ndb

class Bill(ndb.Model):
    user_email = ndb.StringProperty( required = True )
    date = ndb.StringProperty( required = True )
    pay_method = ndb.StringProperty( required = True )
    remitente_name = ndb.StringProperty( required = True )
    remitente_cif = ndb.StringProperty( required = True )
    remitente_direccion = ndb.StringProperty( required = True )
    remitente_pais = ndb.StringProperty( required = True )
    remitente_email = ndb.StringProperty( required = True )
    remitente_telefono = ndb.StringProperty( required = True )
    destinatario_name = ndb.StringProperty( required = True )
    destinatario_cif = ndb.StringProperty( required = True )
    destinatario_direccion = ndb.StringProperty( required = True )
    destinatario_pais = ndb.StringProperty( required = True )
    destinatario_email = ndb.StringProperty( required = True )
    destinatario_telefono = ndb.StringProperty( required = True )