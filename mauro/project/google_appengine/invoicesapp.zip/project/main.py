#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import os
import jinja2
import webapp2

from user_entity import User
from bill_entity import Bill

from users_handler import UserHandler
from bills_handler import BillHandler
from invoice_line import InvoiceLine

JINJA_ENVIRONMENT = jinja2.Environment(
 loader=jinja2.FileSystemLoader( os.path.dirname( __file__ ) ),
 extensions=[ "jinja2.ext.autoescape" ],
 autoescape=True )

class DashboardHandler(UserHandler):
    def __init__(self, request=None, response=None):
        self.initialize(request, response)
        
        
    def get(self):
        if self.request.cookies.get("login") == None:
            self.response.delete_cookie("login")
            self.response.delete_cookie("email")
            self.redirect("/")
        else:
            user = User.query( User.email == self.request.cookies.get("email") ).fetch()
            if user == []:
                self.response.delete_cookie("login")
                self.response.delete_cookie("email")
                self.redirect("/")
            else:
                bills = Bill.query( Bill.user_email == user[0].email ).fetch()
                
                template_values = {
                    'name': user[0].name,
                    'email': user[0].email,
                    'bills': bills
                }
                
                template = JINJA_ENVIRONMENT.get_template( "dashboard.html" )
                self.response.write( template.render(template_values) )
        
    def factura(self):
        if self.request.cookies.get("login") == None:
            self.redirect("/")
        else:
            user = User.query( User.email == self.request.cookies.get("email") ).fetch()
            template_values = {
                'name': user[0].name
            }
                
            template = JINJA_ENVIRONMENT.get_template( "dashboard_factura.html" )
            self.response.write( template.render(template_values) )
        
    def graficos(self):
        bills = Bill.query( Bill.user_email == self.request.cookies.get("email") ).fetch()
        user = User.query( User.email == self.request.cookies.get("email") ).fetch()

        if bills != []:
            bills_ids = []
            
            for b in bills:
                bills_ids.append(b.key.id())
                
            invoices = InvoiceLine.query( InvoiceLine.bill_id.IN(bills_ids) ).fetch()
                
            template_values = {
                    'bills': bills,
                    'invoices': invoices,
                    'error': 0,
                    'name': user[0].name
                }
            
            template = JINJA_ENVIRONMENT.get_template( "dashboard_graficos.html" )
            self.response.write( template.render(template_values) )
        else:
            template = JINJA_ENVIRONMENT.get_template( "dashboard_graficos.html" )
            self.response.write( template.render({"error": 1}) )
      
config = {}
config['webapp2_extras.sessions'] = {
    'secret_key': 'claveSecreta',
}        

app = webapp2.WSGIApplication([
#  Routes for users
   webapp2.Route('/register/checkEmail', handler="main.UserHandler", handler_method="checkEmail"),
   webapp2.Route('/register/doLogin', handler="main.UserHandler", handler_method="doLogin"),
   webapp2.Route('/register/doLogout', handler="main.UserHandler", handler_method="doLogout"),
   webapp2.Route('/register/changePassword', handler="main.UserHandler", handler_method="changePass"),
   webapp2.Route('/register/changeName', handler="main.UserHandler", handler_method="changeName"),
#  Routes for bills
   webapp2.Route('/bill/getBill', handler="main.BillHandler", handler_method="getBill"),
   webapp2.Route('/bill/add', handler="main.BillHandler", handler_method="addBill"),
#  Routes for dashboard
   webapp2.Route('/dash/factura', handler="main.DashboardHandler", handler_method="factura"),
   webapp2.Route('/dash/factura', handler="main.DashboardHandler", handler_method="factura"),
   webapp2.Route('/dash/graficos', handler="main.DashboardHandler", handler_method="graficos"),
#  Generic Routes
   ('/register', UserHandler),
   ('/dash', DashboardHandler),
   ('/dash', BillHandler),
], debug=True, config=config)
